let stopwatchInterval;
let startTime;
let elapsedTime = 0;

function startStopwatch() {
    startTime = Date.now() - elapsedTime;
    stopwatchInterval = setInterval(updateStopwatch, 10);
    toggleButtons(true);
}

function stopStopwatch() {
    clearInterval(stopwatchInterval);
    toggleButtons(false);
}

function resetStopwatch() {
    clearInterval(stopwatchInterval);
    elapsedTime = 0;
    updateDisplay();
    toggleButtons(false);
}

function updateStopwatch() {
    elapsedTime = Date.now() - startTime;
    updateDisplay();
}

function updateDisplay() {
    const displayElement = document.querySelector('.display');
    const formattedTime = formatTime(elapsedTime);
    displayElement.textContent = formattedTime;
}

function formatTime(milliseconds) {
    const totalSeconds = Math.floor(milliseconds / 1000);
    const hours = Math.floor(totalSeconds / 3600).toString().padStart(2, '0');
    const minutes = Math.floor((totalSeconds % 3600) / 60).toString().padStart(2, '0');
    const seconds = (totalSeconds % 60).toString().padStart(2, '0');
    return `${hours}:${minutes}:${seconds}`;
}

function toggleButtons(running) {
    const startBtn = document.querySelector('.start-btn');
    const stopBtn = document.querySelector('.stop-btn');
    startBtn.disabled = running;
    stopBtn.disabled = !running;
}
